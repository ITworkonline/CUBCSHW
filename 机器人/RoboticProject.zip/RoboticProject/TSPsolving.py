class Solution:
    def __init__(self,X,start_node):
        self.X = X #Matrix
        self.start_node = start_node
        self.array = [[0]*(2**len(self.X)) for i in range(len(self.X))] #next step node
    def transfer(self,sets):
        su = 0
        for s in sets:
            su = su + 2**s # binary transfer
        return su
    def tsp(self):
        s = self.start_node
        num = len(self.X)
        cities = []
        for i in range(num):
            cities.append(i)
        past_sets = [s] #passed nodes
        cities.pop(cities.index(s)) #set of nodes havent pass
        node = s #start node
        return self.solve(node,cities) #
    def solve(self,node,future_sets):
        # no nodes havent pass, go back to start node
        if len(future_sets) == 0:
            return self.X[node][self.start_node]
        d = 99999
        distance = []
        for i in range(len(future_sets)):
            s_i = future_sets[i]
            copy = future_sets[:]
            copy.pop(i) # ith node has passed
            distance.append(self.X[node][s_i] + self.solve(s_i,copy))
        d = min(distance)
        next_one = future_sets[distance.index(d)]
        c = self.transfer(future_sets)
        self.array[node][c] = next_one
        return d
