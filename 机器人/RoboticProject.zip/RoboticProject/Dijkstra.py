import numpy as np
class Dijhkstra:
    YC: int

    def __init__(self,worldmap):
        self.map = worldmap
        self.XC = len(self.map)
        self.YC = len(self.map[0])
    def vertex_index_to_ij_coordinates(self, v_idx):
        i = v_idx % self.XC
        j = v_idx / self.YC
        if (i < 0) or (j < 0) or (i >= self.XC) or (j >= self.YC):
            return False
        if self.map[i][int(j)]==0:
            return False
        return i, int(j)
    def ij_to_vertex(self, i, j):
        return j*self.XC+i
    def ij_to_xy(self, i, j):
        if i < 0 or j < 0 or i > self.XC or j > self.YC:
            return False
        x = (i+0.5)*(self.Xsize/self.XC)
        y = (j+0.5)*(self.Ysize/self.YC)
        return x,y
    def xy_to_ij(self, x, y):
        if x < 0 or y < 0 or x >= self.Xsize or y >= self.Ysize:
            return False
        i = int((x/self.Xsize)*self.XC)
        j = int((y/self.Ysize)*self.YC)
        return i, j
    def isnotempty(self, l):
        for i in range(len(l)):
            if l[i]>=0:
                return True
        return False
    def get_min_index(self, l):
        min = 0
        for i in range(len(l)):
            if l[min]<0 or (l[i] < l[min] and l[i] >= 0):
                min = i
        if l[min] == -1:
            return -1
        return min
    def get_cost(self, sourcev, dstv):
        if self.vertex_index_to_ij_coordinates(sourcev) == False:
            return np.infty
        if self.vertex_index_to_ij_coordinates(dstv) == False:
            return np.infty
        si, sj = self.vertex_index_to_ij_coordinates(sourcev)
        di, dj = self.vertex_index_to_ij_coordinates(dstv)
        if(self.map[di][dj]==0):
            return np.infty
        if np.abs(si-di)+np.abs(sj-dj) <= 1:
            aren = 1
        else:
            aren = 0
        if aren == 1:
            return 1;
        else:
            return np.infty
    def run_dj(self, sourcev):
        dist = [np.infty]*self.XC*self.YC
        Q_cost = [-1]*self.XC*self.YC
        prev = [-1]*self.XC*self.YC
        dist[sourcev] = 0
        Q_cost[sourcev] = 0

        while self.isnotempty(Q_cost)==True:
            min_index = self.get_min_index(Q_cost)
            if(min_index < 0):
                break
            Q_cost[min_index] = -1
            for b in range(self.XC*self.YC):
                travel_cost = self.get_cost(min_index, b)
                if(travel_cost == np.infty):
                    continue
                alt = dist[min_index]+travel_cost
                if(alt < dist[b]):
                    dist[b] = alt
                    Q_cost[b] = alt
                    prev[b] = min_index
        return prev
    def path(self, prev, sourcev, endv):
        path = [""]*self.XC*self.YC
        path[0] = -1
        path[1] = endv

        cur_v = endv
        cur_index = 2
        while cur_v!=sourcev and cur_v!=-1:
            path[cur_index] = prev[cur_v]
            cur_index=cur_index+1
            cur_v = prev[cur_v]
        finalpath = [""]*cur_index
        for i in range(cur_index):
            finalpath[i] = path[cur_index-i-1]
        return finalpath
