import numpy as np
from PIL import Image


class Imagesensor:
    def __init__(self, imagefile):
        self.red = (234, 128, 128)
        self.img = Image.open(imagefile)
    def constructMatrix(self):
        self.img.load()
        imgwidth, imgheight = self.img.size    #1256 * 888
        result = np.ones((4, 4), dtype = int)
        for i in range(imgheight):
            for j in range(imgwidth):
                pix = self.img.getpixel((j, i))
                if pix == self.red:
                    if int(i / 314)<4 and int(j / 355)<4:
                        result[int(i / 314), int(j / 355)] = 0
        return result




