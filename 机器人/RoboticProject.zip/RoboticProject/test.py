from time import sleep
import serial
ser = serial.Serial('COM4', 9600)
ser.write(str.encode('ffRf')) # Convert the decimal number to ASCII then send it to the Arduino
