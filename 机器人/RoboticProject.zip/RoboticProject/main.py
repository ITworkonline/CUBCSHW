from TSPsolving import Solution
from Dijkstra import Dijhkstra
from imgexe import Imagesensor
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import serial

def main():
    print("To see the pictures, the number is present for the location and 0 is where you will have all your packages!")
    lena = mpimg.imread('map2.jpg')
    plt.imshow(lena)
    plt.axis('off')
    plt.show()
    x = input("Now, choose where will the packages go! (Seperated by the space) ")
    ll = x.split()
    li = []
    for i in ll:
        li.append(int(i))
    im = Imagesensor("map.jpg")

    Worldmap = im.constructMatrix().tolist()
    Di = Dijhkstra(Worldmap)
    lis = [0]+li
    line = [-1] * len(lis)
    cost = [list(line) for i in range(len(lis))]
    line2 = [0] * len(lis)
    path = [list(line2) for i in range(len(lis))]
    for i in range(len(lis)):
        for j in range(len(lis)):
            if i == j:
                cost[i][j] = -1
                path[i][j] = []
            else:
                prev = Di.run_dj(lis[i])
                path[i][j] = Di.path(prev, lis[i], lis[j])
                cost[i][j] = len(path[i][j]) - 2
    finalpath = []

    S = Solution(cost, 0)
    S.tsp()
    lists = []
    for i in range(len(S.X)):
        lists.append(i)
    start = S.start_node
    while len(lists) > 0:
        lists.pop(lists.index(start))
        m = S.transfer(lists)
        next_node = S.array[start][m]
        print(start, "--->", next_node)
        finalpath = finalpath + (path[start][next_node][1:-1])
        start = next_node
    finalpath = [0]+finalpath
    print("The final path will be: ", finalpath)

    transformdata=""
    head = 'w'
    for i in range(len(finalpath)-1):
        if finalpath[i+1]==finalpath[i]+1:
            if head == 'w':
                transformdata = transformdata + 'r'
                head = 'd'
            elif head == 'a':
                transformdata = transformdata + 'R'
                head = 'd'
            elif head == 's':
                transformdata = transformdata + 'l'
                head = 'd'
            elif head == 'd':
                transformdata = transformdata + 'f'
                head = 'd'
        elif finalpath[i+1]==finalpath[i]-1:
            if head == 'w':
                transformdata = transformdata + 'l'
                head = 'a'
            elif head == 'a':
                transformdata = transformdata + 'f'
                head = 'a'
            elif head == 's':
                transformdata = transformdata + 'r'
                head = 'a'
            elif head == 'd':
                transformdata = transformdata + 'R'
                head = 'a'
        elif finalpath[i+1]==finalpath[i]+len(Worldmap):
            if head == 'w':
                transformdata = transformdata + 'f'
                head = 'w'
            elif head == 'a':
                transformdata = transformdata + 'r'
                head = 'w'
            elif head == 's':
                transformdata = transformdata + 'R'
                head = 'w'
            elif head == 'd':
                transformdata = transformdata + 'l'
                head = 'w'
        elif finalpath[i+1]==finalpath[i]-len(Worldmap):
            if head == 'w':
                transformdata = transformdata + 'R'
                head = 's'
            elif head == 'a':
                transformdata = transformdata + 'l'
                head = 's'
            elif head == 's':
                transformdata = transformdata + 'f'
                head = 's'
            elif head == 'd':
                transformdata = transformdata + 'r'
                head = 's'
        if finalpath[i+1] in li:
                transformdata = transformdata + 'g'
                li.remove(finalpath[i+1])
    ser = serial.Serial('COM4', 9600)
    ser.write(str.encode(transformdata))
    print(transformdata)
    print(Worldmap)

if __name__ == "__main__":
    main()





